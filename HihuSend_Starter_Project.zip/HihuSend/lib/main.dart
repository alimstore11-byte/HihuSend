import 'dart:async';
import 'package:flutter/material.dart';
import 'models/chat_message.dart';
import 'services/wifi_chat_service.dart';

void main() => runApp(const HihuSendApp());

class HihuSendApp extends StatelessWidget {
  const HihuSendApp({super.key});

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF101B35);
    const blue = Color(0xFF3478F6);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'HihuSend',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF4F7FC),
        appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
      ),
      home: const ChatHomePage(),
    );
  }
}

class ChatHomePage extends StatefulWidget {
  const ChatHomePage({super.key});
  @override
  State<ChatHomePage> createState() => _ChatHomePageState();
}

class _ChatHomePageState extends State<ChatHomePage> {
  final _service = WifiChatService();
  final _text = TextEditingController();
  final _scroll = ScrollController();
  final List<ChatMessage> _messages = [];
  StreamSubscription<ChatMessage>? _subscription;
  String _status = 'Belum terhubung';
  String _connectionInfo = 'Pilih cara menghubungkan perangkat';
  bool _connected = false;
  bool _isHost = false;

  @override
  void initState() {
    super.initState();
    _subscription = _service.messages.listen((message) {
      if (!mounted) return;
      setState(() => _messages.add(message));
      _scrollToBottom();
    });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _startHost() async {
    try {
      final ip = await _service.startServer();
      setState(() {
        _connected = true;
        _isHost = true;
        _status = 'Jaringan lokal aktif';
        _connectionInfo = 'IP perangkat ini: $ip  •  Port: ${WifiChatService.port}';
      });
      _addSystem('Server HihuSend aktif. Minta teman bergabung menggunakan IP di atas.');
    } catch (e) {
      _showError('Gagal membuat server: $e');
    }
  }

  Future<void> _joinDialog() async {
    final controller = TextEditingController();
    final ip = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Gabung ke teman'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'Alamat IP teman',
            hintText: 'Contoh: 192.168.43.1',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()),
              child: const Text('Hubungkan')),
        ],
      ),
    );
    if (ip == null || ip.isEmpty) return;
    try {
      await _service.connect(ip);
      setState(() {
        _connected = true;
        _isHost = false;
        _status = 'Terhubung ke jaringan lokal';
        _connectionInfo = 'Terhubung ke $ip:${WifiChatService.port}';
      });
      _addSystem('Berhasil terhubung ke perangkat teman.');
    } catch (e) {
      _showError('Tidak dapat terhubung. Pastikan satu WiFi/hotspot dan IP benar.\n$e');
    }
  }

  void _addSystem(String text) {
    setState(() => _messages.add(ChatMessage(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      sender: 'Sistem', text: text, time: DateTime.now(), isSystem: true,
    )));
    _scrollToBottom();
  }

  Future<void> _send() async {
    final value = _text.text.trim();
    if (value.isEmpty) return;
    if (!_connected) {
      _showError('Hubungkan perangkat terlebih dahulu.');
      return;
    }
    final message = ChatMessage(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      sender: 'Saya', text: value, time: DateTime.now(), isMine: true,
    );
    setState(() => _messages.add(message));
    _text.clear();
    _scrollToBottom();
    try {
      await _service.sendText(value);
    } catch (e) {
      _showError('Pesan gagal dikirim: $e');
    }
  }

  Future<void> _disconnect() async {
    await _service.disposeConnection();
    setState(() {
      _connected = false;
      _status = 'Tidak terhubung';
      _connectionInfo = 'Pilih cara menghubungkan perangkat';
    });
    _addSystem('Koneksi diputus.');
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _service.dispose();
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(width: 36, height: 36,
            decoration: BoxDecoration(color: Colors.white.withOpacity(.15), borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.forum_rounded, color: Colors.white)),
          const SizedBox(width: 10),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('HihuSend', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 19)),
            Text('Offline Messenger', style: TextStyle(fontSize: 11, color: Colors.white70)),
          ]),
        ]),
        actions: [
          IconButton(
            tooltip: _connected ? 'Putuskan koneksi' : 'Koneksi',
            onPressed: _connected ? _disconnect : _showConnectionOptions,
            icon: Icon(_connected ? Icons.link_off : Icons.wifi_tethering),
          )
        ],
      ),
      body: Column(children: [
        _connectionCard(),
        Expanded(
          child: _messages.isEmpty
              ? _emptyState()
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 16),
                  itemCount: _messages.length,
                  itemBuilder: (context, index) => _bubble(_messages[index]),
                ),
        ),
        _composer(),
      ]),
    );
  }

  Widget _connectionCard() => Container(
    margin: const EdgeInsets.fromLTRB(14, 14, 14, 8),
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(16),
      border: Border.all(color: const Color(0xFFE5EAF3)),
    ),
    child: Row(children: [
      Icon(_connected ? Icons.wifi : Icons.wifi_off,
          color: _connected ? Colors.green : Colors.orange),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(_status, style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 3),
        Text(_connectionInfo, style: const TextStyle(fontSize: 11, color: Colors.black54)),
      ])),
      if (!_connected)
        IconButton(onPressed: _showConnectionOptions, icon: const Icon(Icons.add_link, color: Color(0xFF3478F6))),
    ]),
  );

  Widget _emptyState() => Center(child: Padding(
    padding: const EdgeInsets.all(30),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 86, height: 86,
        decoration: const BoxDecoration(color: Color(0xFFE7EFFF), shape: BoxShape.circle),
        child: const Icon(Icons.forum_outlined, size: 42, color: Color(0xFF3478F6))),
      const SizedBox(height: 16),
      const Text('Percakapan dimulai di sini', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
      const SizedBox(height: 7),
      const Text('Hubungkan HP melalui WiFi atau hotspot yang sama, lalu kirim pesan tanpa internet.',
          textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, height: 1.4)),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: _showConnectionOptions,
          icon: const Icon(Icons.devices), label: const Text('Hubungkan perangkat')),
    ]),
  ));

  Widget _bubble(ChatMessage m) {
    if (m.isSystem) {
      return Center(child: Container(
        margin: const EdgeInsets.symmetric(vertical: 7),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(color: const Color(0xFFE8EDF5), borderRadius: BorderRadius.circular(20)),
        child: Text(m.text, textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 11, color: Colors.black54)),
      ));
    }
    return Align(
      alignment: m.isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 300),
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.fromLTRB(13, 9, 13, 7),
        decoration: BoxDecoration(
          color: m.isMine ? const Color(0xFFDCEAFF) : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16), topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(m.isMine ? 16 : 4),
            bottomRight: Radius.circular(m.isMine ? 4 : 16),
          ),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (!m.isMine) Text(m.sender,
              style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF3478F6), fontSize: 11)),
          Text(m.text, style: const TextStyle(fontSize: 14)),
          const SizedBox(height: 3),
          Align(alignment: Alignment.bottomRight,
            child: Text('${m.time.hour.toString().padLeft(2, '0')}:${m.time.minute.toString().padLeft(2, '0')}',
                style: const TextStyle(fontSize: 9, color: Colors.black45))),
        ]),
      ),
    );
  }

  Widget _composer() => SafeArea(
    top: false,
    child: Container(
      padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
      color: Colors.white,
      child: Row(children: [
        IconButton(onPressed: () => _showError('Lampiran foto akan ditambahkan pada tahap berikutnya.'),
            icon: const Icon(Icons.add_circle_outline, color: Color(0xFF3478F6))),
        Expanded(child: TextField(
          controller: _text,
          minLines: 1, maxLines: 4,
          textCapitalization: TextCapitalization.sentences,
          decoration: InputDecoration(
            hintText: 'Tulis pesan...',
            filled: true, fillColor: const Color(0xFFF2F5FA),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
          ),
          onSubmitted: (_) => _send(),
        )),
        const SizedBox(width: 8),
        CircleAvatar(backgroundColor: const Color(0xFF3478F6),
          child: IconButton(onPressed: _send, icon: const Icon(Icons.send_rounded, color: Colors.white, size: 19))),
      ]),
    ),
  );

  Future<void> _showConnectionOptions() async {
    showModalBottomSheet(
      context: context, showDragHandle: true, builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Hubungkan perangkat', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('Tahap awal menggunakan WiFi/hotspot lokal. Internet tidak diperlukan.',
                style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 16),
            ListTile(
              leading: const CircleAvatar(child: Icon(Icons.wifi_tethering)),
              title: const Text('Buat jaringan chat'),
              subtitle: const Text('HP ini menjadi server. Bagikan IP kepada teman.'),
              onTap: () { Navigator.pop(context); _startHost(); },
            ),
            ListTile(
              leading: const CircleAvatar(child: Icon(Icons.link)),
              title: const Text('Gabung ke jaringan teman'),
              subtitle: const Text('Masukkan IP HP yang membuat jaringan chat.'),
              onTap: () { Navigator.pop(context); _joinDialog(); },
            ),
            ListTile(
              leading: const CircleAvatar(child: Icon(Icons.bluetooth)),
              title: const Text('Bluetooth'),
              subtitle: const Text('Modul BLE lintas Android/iOS disiapkan pada tahap berikutnya.'),
              enabled: false,
            ),
          ]),
        ),
      ),
    );
  }
}
