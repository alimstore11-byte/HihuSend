class ChatMessage {
  final String id;
  final String sender;
  final String text;
  final DateTime time;
  final bool isMine;
  final bool isSystem;

  const ChatMessage({
    required this.id,
    required this.sender,
    required this.text,
    required this.time,
    this.isMine = false,
    this.isSystem = false,
  });
}
