import 'dart:async';
import 'dart:convert';
import 'dart:io';
import '../models/chat_message.dart';

/// MVP transport: TCP socket over the same WiFi/hotspot LAN.
/// One device runs the server; other devices connect using its local IP.
class WifiChatService {
  static const int port = 40444;
  final _messages = StreamController<ChatMessage>.broadcast();
  final List<Socket> _clients = [];
  ServerSocket? _server;
  Socket? _client;
  StreamSubscription<String>? _clientLines;
  final Map<Socket, StreamSubscription<String>> _serverLines = {};

  Stream<ChatMessage> get messages => _messages.stream;

  Future<String> startServer() async {
    await disposeConnection();
    final addresses = await NetworkInterface.list(
      type: InternetAddressType.IPv4,
      includeLoopback: false,
    );
    if (addresses.isEmpty || addresses.every((a) => a.addresses.isEmpty)) {
      throw Exception('Tidak menemukan alamat IPv4. Aktifkan WiFi/hotspot terlebih dahulu.');
    }
    _server = await ServerSocket.bind(InternetAddress.anyIPv4, port, shared: true);
    _server!.listen(_handleIncoming);
    // Prefer a private LAN address, excluding link-local addresses.
    final candidates = addresses.expand((a) => a.addresses)
        .where((a) => !a.isLoopback && !a.address.startsWith('169.254.'))
        .toList();
    if (candidates.isEmpty) throw Exception('IP jaringan lokal tidak ditemukan.');
    return candidates.first.address;
  }

  void _handleIncoming(Socket socket) {
    _clients.add(socket);
    final sub = socket
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen((line) => _receive(line, socket));
    _serverLines[socket] = sub;
    socket.done.then((_) {
      _clients.remove(socket);
      _serverLines.remove(socket)?.cancel();
    });
  }

  Future<void> connect(String host) async {
    await disposeConnection();
    _client = await Socket.connect(host, port, timeout: const Duration(seconds: 8));
    _clientLines = _client!
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen((line) => _receive(line, null));
  }

  void _receive(String line, Socket? source) {
    try {
      final data = jsonDecode(line) as Map<String, dynamic>;
      final text = data['text'] as String? ?? '';
      final sender = data['sender'] as String? ?? 'Teman';
      if (text.isEmpty) return;
      _messages.add(ChatMessage(
        id: data['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
        sender: sender,
        text: text,
        time: DateTime.tryParse(data['time']?.toString() ?? '') ?? DateTime.now(),
      ));
      // Relay messages to other connected clients (basic group-chat behavior).
      if (source != null) {
        for (final peer in _clients.toList()) {
          if (!identical(peer, source)) {
            peer.write('$line\n');
          }
        }
      }
    } catch (_) {
      // Ignore malformed packets; production version should log safely.
    }
  }

  Future<void> sendText(String text) async {
    final packet = jsonEncode({
      'id': DateTime.now().microsecondsSinceEpoch.toString(),
      'sender': 'Teman',
      'text': text,
      'time': DateTime.now().toIso8601String(),
    });
    if (_client != null) {
      _client!.write('$packet\n');
      await _client!.flush();
      return;
    }
    if (_server != null && _clients.isNotEmpty) {
      for (final peer in _clients.toList()) {
        peer.write('$packet\n');
        await peer.flush();
      }
      return;
    }
    throw Exception('Belum ada koneksi aktif.');
  }

  Future<void> disposeConnection() async {
    await _clientLines?.cancel();
    _clientLines = null;
    _client?.destroy();
    _client = null;
    for (final sub in _serverLines.values) {
      await sub.cancel();
    }
    _serverLines.clear();
    for (final peer in _clients) {
      peer.destroy();
    }
    _clients.clear();
    await _server?.close();
    _server = null;
  }

  Future<void> dispose() async {
    await disposeConnection();
    await _messages.close();
  }
}
